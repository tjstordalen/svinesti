// Hook up to HTML document.
var cvs = document.getElementById("canvas");
var ctx = cvs.getContext("2d");

var btnStep = document.getElementById("btnStep");
btnStep.onclick = function () {
    if (!isPaused) return; // Only works in pause mode.
    isStepQueued = true;
}

var btnPlay = document.getElementById("btnPlayPause");
btnPlay.onclick = function () {
    isPaused = !isPaused;
    btnPlay.innerText = isPaused ? "Play" : "Pause";
    btnStep.disabled  = !isPaused;
}

var lblSpeed = document.getElementById("lblSpeed");
var sldSpeed = document.getElementById("sldSpeed");
sldSpeed.oninput = function () {
    playSpeed = sldSpeed.value / 10;
    lblSpeed.innerText = "Speed: " + playSpeed;
}
sldSpeed.value = 30;
sldSpeed.oninput(); // Set initial values.

var btnReset = document.getElementById("btnReset");
btnReset.onclick = function () {
    btnPlay.innerText = "Play";
    btnStep.disabled = false;
    txtLog.value = "Index\tMove\tLine\n";

    isPaused     = true;
    isDone       = false;
    isStepQueued = false;

    playerX   = initialPlayerX;
    playerY   = initialPlayerY;
    playerRot = initialPlayerRot;
    starsLeft = initialStarsLeft;
    lvl = copyArray2D(initialLvl);

    startMove(0);
}

var txtLog = document.getElementById("txtLog");
txtLog.value = "Index\tMove\tLine\n";

var backupLevelString =
`RRRB
...R
...R
...R
0 3 r`;

var backupMovesString =
`m
b?
m
b?
m
b?
r
m
b?
m
b?
m
won`;

// NOTE: CodeJudge replaces these markers with the test input (level) and player moves (output).
//       To allow us to run locally also, we fall back on hardcoded values.
//       In these check we circumvent the substitution by ignoring the outermost '%' pair.
var levelString = "%%%CJ:input%%%";
var movesString = "%%%CJ:output%%%";
if (levelString === null || levelString.substring(1, levelString.length - 1) === "%%CJ:input%%")  levelString = backupLevelString;
if (movesString === null) movesString = ""; // Happens in "example test".
else if (movesString.substring(1, movesString.length - 1) === "%%CJ:output%%") movesString = backupMovesString;

var playerX = 0;
var playerY = 0;
var playerRot = 0; // Rotation in radians.
var starsLeft = 0;
var lvlWidth   = 0;
var lvlHeight  = 0;
var cellWidth  = 0;
var cellHeight = 0;
var lvl   = null;
var moves = null;

var timeLastFrame = 0;

var curMoveIdx = 0;
var curMoveT = 0;
var curMoveFromX = 0;
var curMoveFromY = 0;
var curMoveFromRot = 0;
var curMoveToX = 0;
var curMoveToY = 0;
var curMoveToRot = 0;
var curMoveColor = "#000000"; // Fill style format.
var curMoveAlpha = 0;
var curMoveIsQuery = false; // If this gets more complicated, use an enum or the like.

var playSpeed = 3; // Unit is "moves animated per second".
var isPaused = true;
var isDone = false;
var isStepQueued = false;

var initialPlayerX = 0;
var initialPlayerY = 0;
var initialPlayerRot = 0;
var initialStarsLeft = 0;
var initialLvl = null;

const maxTurnCount = 1000; // NOTE: This should be synchronized with the driver!

const colorQueryBlue  = "#473ef0";
const colorQueryRed   = "#e83c3c";
const colorQueryGreen = "#25cc38";

// We use this fairly crude system to ensure that images are loaded before we use them.
var isPlayerLoaded = false;
var isStarLoaded = false;

// NOTE: Due to restriction on CodeJudge, we have to host and load pictures from another service.
//       In this case we chose my personal website.
// Not sure if the "crossorigin" is necessary, but I have run into problems without this before.
var imgPlayer = new Image;
imgPlayer.crossorigin = 'anonymous';
imgPlayer.onload = function () { isPlayerLoaded = true; }
imgPlayer.src = "https://people.compute.dtu.dk/mhrpe/bootcamp/robot.png";

var imgStar = new Image;
imgStar.crossorigin = 'anonymous'; // Not sure if this is necessary, but I have run into problems without this before.
imgStar.onload = function () { isStarLoaded = true; }
imgStar.src = "https://people.compute.dtu.dk/mhrpe/bootcamp/star.png";

function isTile(cell) {
    return cell !== '.';
}
function isStar(cell) {
    return cell === 'R' || cell === 'G' || cell === 'B' || cell === 'N';
}
function tileColor(cell) {
    var c = cell.toLowerCase();
    if (c === 'r') return "#DD2222";
    if (c === 'g') return "#22DD22";
    if (c === 'b') return "#2222DD";
    return "#CCCCCC"; // No color (allowed).
}

function copyArray2D(arr) {
    var cpy = Array.from(arr);
    for (var i = 0; i < cpy.length; i++) cpy[i] = Array.from(cpy[i]);
    return cpy;
}
function lerp(t, from, to) {
    return from + (to - from) * t;
}
function colorEaseInAndOut(t) {
    t = t <= 0.5 ? t*2 : 1 - (t-0.5)*2;
    return 1 - Math.pow(1 - t, 3);
}
function startMove(moveIdx) {
    curMoveT = 0;
    curMoveIdx = moveIdx;

    // The first word is the actual move, everything else is interpreted as comments.
    var moveParts = moves[moveIdx].split(/[ \t]+/);
    var move = moveParts[0];
    var moveLineNum = null;
    if (moveParts.length > 1) {
        moveLineNum = parseInt(moveParts[1]);
        if (isNaN(moveLineNum)) {
            moveLineNum = null;
            console.error("Failed to parse line number in '%s' (line %d)", moves[moveIdx], moveIdx);
        }
    }

    var dx = 0
    var dy = 0
    var drad = 0
    var color = "#000000"
    var alpha = 0
    var isQuery = false;
    if (move === 'm') {
        dx = Math.cos(playerRot);
        dy = Math.sin(playerRot);
    } else if (move === 'l') {
        drad =  Math.PI * 0.5;
    } else if (move === 'r') {
        drad = -Math.PI * 0.5;
    } else if (move === "r?") {
        color = colorQueryRed;
        alpha = 1;
        isQuery = true;
    } else if (move === "g?") {
        color = colorQueryGreen;
        alpha = 1;
        isQuery = true;
    } else if (move === "b?") {
        color = colorQueryBlue;
        alpha = 1;
        isQuery = true;
    } else if (move === "won" || move === "lost") {
        // We simply ignore these as they have no impact (yet).
    } else {
        console.error("Unsupported move: " + move);
    }

    curMoveFromX   = playerX;
    curMoveFromY   = playerY;
    curMoveFromRot = playerRot;
    curMoveToX     = curMoveFromX + dx;
    curMoveToY     = curMoveFromY + dy;
    curMoveToRot   = curMoveFromRot + drad;
    curMoveColor   = color;
    curMoveAlpha   = alpha;
    curMoveIsQuery = isQuery

    if (moveLineNum !== null) {
        txtLog.value += curMoveIdx + "\t" + move + "\t" + moveLineNum + "\n";
    } else {
        txtLog.value += curMoveIdx + "\t" + move + "\n";
    }
}
function startNextMove() {
    curMoveIdx++;
    if (!isDone && curMoveIdx < moves.length) {
        startMove(curMoveIdx);
    } else {
        isDone = true;
    }
}

function pickUpStarIfPossible() {
    if (isStar(lvl[playerY][playerX])) {
        // Pick up star if it is present.
        lvl[playerY][playerX] = lvl[playerY][playerX].toLowerCase();
        starsLeft--;
        if (starsLeft <= 0) isDone = true; // Victory.
    }
}
function tick() {
    var timeNow = Date.now();
    var deltaTime = (timeNow - timeLastFrame) / 1000; // In seconds.
    timeLastFrame = timeNow;

    // If we are not done loading, simply delay.
    if (!isPlayerLoaded || !isStarLoaded) {
        requestAnimationFrame(tick);
    }

    // Move player.
    var isTimedOut = curMoveIdx >= maxTurnCount;
    if (!isDone && !isTimedOut) {
        // If paused, we finish animating the current move if we've begun it.
        // Stepping allows us to start the next move anyway (once).
        var isStoppedDueToPause = curMoveT === 0 && isPaused;
        if (isStoppedDueToPause && isStepQueued) {
            isStepQueued = false;
            isStoppedDueToPause = false;
        }
        if (curMoveT < 1 && !isStoppedDueToPause) { // Animate current move.
            curMoveT  = Math.min(1, curMoveT + deltaTime * playSpeed);
            playerX   = lerp(curMoveT, curMoveFromX, curMoveToX);
            playerY   = lerp(curMoveT, curMoveFromY, curMoveToY);
            playerRot = lerp(curMoveT, curMoveFromRot, curMoveToRot);
        }

        // This is not an "else" branch, so we avoid a frame where there is no movement.
        if (curMoveT >= 1) {
            playerX = Math.round(playerX); // This seems a little brittle, but is very simple and should work.
            playerY = Math.round(playerY);

            // Check if we died due to out-of-bounds.
            if (playerX < 0 || playerX >= lvlWidth || playerY < 0 || playerY >= lvlHeight) {
                isDone = true;
            } else if (!isTile(lvl[playerY][playerX])) {
                isDone = true;
            } else {
                pickUpStarIfPossible();
            }

            startNextMove();
        }
    }

    // Clear canvas.
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, cvs.width, cvs.height);

    // Draw board.
    for (var j = 0; j < lvlHeight; j++) {
        for (var i = 0; i < lvlWidth; i++) {
            var cell = lvl[j][i];
            var cx = i * cellWidth;
            var cy = (lvlHeight - 1 - j) * cellHeight; // (0, 0) at bottom-left.

            if (isTile(cell)) {
                ctx.fillStyle = tileColor(cell);
                ctx.fillRect(cx, cy, cellWidth, cellHeight);
                if (isStar(cell)) {
                    // Draw a star.
                    ctx.drawImage(imgStar, cx, cy, cellWidth, cellHeight);
                }
            } else {
                ctx.fillStyle = "#999999";
                ctx.fillRect(cx, cy, cellWidth, cellHeight);
            }
        }
    }

    // Draw player.
    var px = playerX * cellWidth;
    var py = (lvlHeight - 1 - playerY) * cellHeight;

    ctx.translate(px + cellWidth / 2, py + cellHeight / 2); // Move matrix to center of sprite.
    ctx.rotate(-playerRot); // Rotates CW, but radians are specified CCW.
    ctx.translate(-(px + cellWidth / 2), -(py + cellHeight / 2)); // Move sprite into position.

    // Draw the player.
    ctx.drawImage(imgPlayer, px, py, cellWidth, cellHeight);

    // Reverse above transformations (note reverse order).
    ctx.translate(px + cellWidth / 2, py + cellHeight / 2);
    ctx.rotate(playerRot);
    ctx.translate(-(px + cellWidth / 2), -(py + cellHeight / 2));

    // Animate query indicator.
    ctx.globalAlpha = curMoveIsQuery ? colorEaseInAndOut(curMoveT) : 0;
    ctx.font = cellWidth + "px Arial Black";
    ctx.fillStyle = "#000000"; // We draw outline by first stroking the outline in black.
    ctx.lineWidth = 2;
    ctx.strokeText("?", px + cellWidth / 2, py + cellHeight / 2);
    ctx.fillStyle = curMoveColor;
    ctx.fillText("?", px + cellWidth / 2, py + cellHeight / 2);
    ctx.globalAlpha = 1

    // Draw message on top if timed out.
    if (isTimedOut) {
        ctx.fillStyle = "#000000";
        var msg = "Timed out due to exceeding the maximum turn count (" + maxTurnCount + ")";
        var fontSize = cellWidth // We search for a font small enough to fit...
        do {
            ctx.font = fontSize + "px Arial Black";
            fontSize -= 4;
        } while(ctx.measureText(msg).width > cvs.width);

        ctx.fillText(msg, cvs.width / 2, cvs.height / 2);
    }

    requestAnimationFrame(tick); // Queue next frame.
}

// NOTE: There is no error checking on this side, only in the driver.
function initialize() {
    var parts = levelString.trim().split(/[ \n]/); // Remove empty lines from both end.
    playerX = parseInt(parts[parts.length - 3]);
    playerY = parseInt(parts[parts.length - 2]);

    var rot = parts[parts.length - 1];
    if (rot === 'r')      playerRot = 0;
    else if (rot === 'u') playerRot = 0.5 * Math.PI;
    else if (rot === 'l') playerRot = 1.0 * Math.PI;
    else if (rot === 'd') playerRot = 1.5 * Math.PI;

    lvlHeight = parts.length - 3;
    lvl = parts.slice(0, lvlHeight).map(function (l) { return l.split(""); });
    lvl.reverse(); // (0, 0) at bottom-left.

    // We pad incomplete rows to the full length.
    lvlWidth = Math.max(... lvl.map(function (r) { return r.length; }));
    for (var row of lvl) {
        while (row.length < lvlWidth) row.push('.');
    }

    // Count the number of stars in the level.
    starsLeft = 0;
    for (var row of lvl) {
        for (var cell of row) starsLeft += isStar(cell) ? 1 : 0;
    }

    // Square cells look nicer.
    var cellSize = Math.min(cvs.width  / lvlWidth, cvs.height / lvlHeight);
    cellWidth  = cellSize;
    cellHeight = cellSize;

    // Since we stop if we go above the maximum turn count, we do not load moves than that.
    moves = movesString.trim().split("\n"); // Remove empty lines from both ends.
    if (moves.length > maxTurnCount) moves.slice(0, maxTurnCount + 1);

    // If the player starts on a star we pick it up immediately.
    // NOTE: This is done /before/ we save the initial level data,
    //       so we do not need to repeat this process on reset.
    pickUpStarIfPossible();

    // Save initial values for future resets.
    initialPlayerX = playerX;
    initialPlayerY = playerY;
    initialPlayerRot = playerRot;
    initialStarsLeft = starsLeft;
    initialLvl = copyArray2D(lvl);

    // Set up text drawing (currently only used for color query indication).
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    startMove(0);
}

// Execution begins here.
initialize();
timeLastFrame = Date.now(); // Avoid first frame having huge delta time (will be zero now).
tick(); // Go!
