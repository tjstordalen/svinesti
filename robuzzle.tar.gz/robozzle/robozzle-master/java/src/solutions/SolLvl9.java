public class SolLvl9 {
	public static String level =
            "....G...\n" +
			".RbrbbR.\n" +
			".b.bb.b.\n" +
			"GbbbbbR.\n" +
			".rbbbbbG\n" +
			".b.bb.b.\n" +
			".RbbrbR.\n" +
			"...G....\n" +
			"3 3 r";

public static void main(String[] args) {
		Robot.loadLevel(level);

		while (true) {
			if (Robot.isBlue()) {
				Robot.move();
			} else if (Robot.isGreen()) {
				Robot.turnRight();
				Robot.turnRight();
				Robot.move();
				Robot.turnLeft();
			} else if (Robot.isRed()) {
				Robot.turnRight();
				Robot.move();
			}
		}
	}
}
