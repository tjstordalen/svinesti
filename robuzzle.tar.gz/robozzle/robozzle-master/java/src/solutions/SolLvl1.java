public class SolLvl1 {
	public static String level =
			"BbbbbbbbbbB\n" +
			"5 0 r";

	public static void main(String[] args) {
		Robot.loadLevel(level);

		Robot.move();
		Robot.move();
		Robot.move();
		Robot.move();
		Robot.move();

		Robot.turnRight();
		Robot.turnRight();

		Robot.move();
		Robot.move();
		Robot.move();
		Robot.move();
		Robot.move();

		Robot.move();
		Robot.move();
		Robot.move();
		Robot.move();
		Robot.move();
	}
}
