public class SolLvl7 {
	public static String level =
            "R..R.......\n" +
			"B..B.R.R...\n" +
			"B..B.B.BR..\n" +
			"BR.B.BRBB..\n" +
			"BB.BRBBBBR.\n" +
			"BBRBBBBBBBR\n" +
			"bBBBBBBBBBB\n" +
			"0 0 r";

public static void main(String[] args) {
		Robot.loadLevel(level);

		while (true) {
			int x = 0;
			Robot.turnLeft();
			while (Robot.isBlue()) {
				x++;
				Robot.move();
			}
			Robot.turnRight();
			Robot.turnRight();
			while (x-- > 0) Robot.move();
			Robot.turnLeft();
			Robot.move();
		}

	}
}
