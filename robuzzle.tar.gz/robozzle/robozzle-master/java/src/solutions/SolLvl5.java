public class SolLvl5 {
	public static String level =
            "bbbR.....\n" +
			"...b.....\n" +
			"...b.....\n" +
			"...bBbbbB\n" +
			"0 3 r";

	public static void main(String[] args) {
		Robot.loadLevel(level);

		int x = 0;
		while (true) {
			if (Robot.isBlue()) {
				x++;
				Robot.move();
			} else if (Robot.isRed()) {
				Robot.turnRight();
				while (x-- > 0) {
					Robot.move();
				}
				Robot.turnLeft();
				while (true) Robot.move();
			}
		}
	}
}
