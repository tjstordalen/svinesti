public class SolLvl4 {
	public static String level =
            "....R\n" +
			"....b\n" +
			"....b\n" +
			"BbbbG\n" +
			"....b\n" +
			"....b\n" +
			"....B\n" +
			"0 3 r";

	public static void main(String[] args) {
		Robot.loadLevel(level);

		while (true) {
			if (Robot.isBlue()) {
				Robot.move();
			} else if (Robot.isGreen()) {
				Robot.turnLeft();
				Robot.move();
				while (true) {
					if (Robot.isRed()) {
						Robot.turnRight();
						Robot.turnRight();
						Robot.move();
					} else {
						Robot.move();
					}
				}
			}
		}
	}
}
