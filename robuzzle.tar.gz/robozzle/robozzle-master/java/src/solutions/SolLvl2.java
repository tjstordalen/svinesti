public class SolLvl2 {
	public static String level =
            "......bB\n" +
			".....bb.\n" +
			"....bb..\n" +
			"...bb...\n" +
			"..bb....\n" +
			".bb.....\n" +
			"bb......\n" +
			"0 0 r";

	public static void main(String[] args) {
		Robot.loadLevel(level);

		while (true) {
			Robot.move();
			Robot.turnLeft();
			Robot.move();
			Robot.turnRight();
		}
	}
}
