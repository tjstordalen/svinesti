public class SolLvl8 {
	public static String level =
            "..GbbbbbbG\n" +
			"..b......b\n" +
			"..b......b\n" +
			"..b..bbbbG\n" +
			"..b.......\n" +
			"..Grg.....\n" +
			"...b......\n" +
			"BbGb......\n" +
			"5 4 r";

public static void main(String[] args) {
		Robot.loadLevel(level);

		while (true) {
			if (Robot.isBlue()) {
				Robot.move();
			} else if (Robot.isGreen()) {
				Robot.turnLeft();
				Robot.move();
			} else if (Robot.isRed()) {
				Robot.turnRight();
				Robot.move();
				Robot.move();
				Robot.turnRight();
				while (true) Robot.move();
			}
		}
	}
}
