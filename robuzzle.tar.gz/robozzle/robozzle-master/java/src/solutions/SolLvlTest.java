// Tutorial 4.
public class SolLvlTest {
	public static String level =
			"rRRRRRRB\n" +
			".......R\n" +
			".......R\n" +
			".......R\n" +
			".......R\n" +
			".......R\n" +
			".......R\n" +
			"0 6 r";

	public static void main(String[] args) {
		Robot.loadLevel(level);

		while (true) {
			Robot.move();
			if (Robot.isBlue()) {
				Robot.turnRight();
			}
		}
	}
}
