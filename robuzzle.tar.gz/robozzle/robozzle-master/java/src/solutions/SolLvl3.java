public class SolLvl3 {
	public static String level =
            "rrrrrrrrrr\n" +
			"BbBbBbBbbb\n" +
			"bBbBbBbBbb\n" +
			"bbBbBbBbBb\n" +
			"bbbBbBbBbB\n" +
			"gggggggggg\n" +
			"0 0 r";

	public static void main(String[] args) {
		Robot.loadLevel(level);

		while (true) {
			if (Robot.isGreen()) {
				Robot.turnLeft();
				Robot.move();
			}
			if (Robot.isBlue()) {
				Robot.move();
			}
			if (Robot.isRed()) {
				Robot.turnRight();
				Robot.move();
			}
		}
	}
}
