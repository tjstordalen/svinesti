public class SolLvl6 {
	public static String level =
            "bbbbR........\n" +
			"....b........\n" +
			"....b........\n" +
			"....bbR......\n" +
			"......b......\n" +
			"......bbbR...\n" +
			".........b...\n" +
			".........b...\n" +
			".........bbbB\n" +
			"0 8 r";

public static void main(String[] args) {
		Robot.loadLevel(level);

		Robot.move();
		while (true) {
			int x = 0;
			while (Robot.isBlue()) {
				Robot.move();
				x++;
			}

			Robot.turnRight();
			while (x-- > 0) {
				Robot.move();
			}
			Robot.turnLeft();
		}

	}
}
