public class SolLvlX {
	public static String level =
            "";

	public static void main(String[] args) {
		Robot.loadLevel(level);

		while (true) {

		}
	}
}
